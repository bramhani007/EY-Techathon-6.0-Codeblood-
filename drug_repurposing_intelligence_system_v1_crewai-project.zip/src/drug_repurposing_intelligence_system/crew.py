import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	SerperDevTool,
	ScrapeWebsiteTool,
	SerplyScholarSearchTool,
	ArxivPaperTool
)





@CrewBase
class DrugRepurposingIntelligenceSystemCrew:
    """DrugRepurposingIntelligenceSystem crew"""

    
    @agent
    def master_drug_repurposing_coordinator(self) -> Agent:
        
        return Agent(
            config=self.agents_config["master_drug_repurposing_coordinator"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def clinical_trials_research_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["clinical_trials_research_specialist"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def patent_intelligence_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["patent_intelligence_analyst"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def market_intelligence_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["market_intelligence_analyst"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def global_trade_intelligence_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["global_trade_intelligence_specialist"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def regulatory_safety_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["regulatory_safety_analyst"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def scientific_literature_knowledge_extraction_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["scientific_literature_knowledge_extraction_specialist"],
            
            
            tools=[				SerperDevTool(),
				SerplyScholarSearchTool(),
				ArxivPaperTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def research_quality_assurance_data_verification_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["research_quality_assurance_data_verification_specialist"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    

    
    @task
    def clinical_trials_analysis(self) -> Task:
        return Task(
            config=self.tasks_config["clinical_trials_analysis"],
            markdown=False,
            
            
        )
    
    @task
    def patent_landscape_intelligence(self) -> Task:
        return Task(
            config=self.tasks_config["patent_landscape_intelligence"],
            markdown=False,
            
            
        )
    
    @task
    def market_opportunity_assessment(self) -> Task:
        return Task(
            config=self.tasks_config["market_opportunity_assessment"],
            markdown=False,
            
            
        )
    
    @task
    def global_trade_flow_analysis(self) -> Task:
        return Task(
            config=self.tasks_config["global_trade_flow_analysis"],
            markdown=False,
            
            
        )
    
    @task
    def regulatory_safety_assessment(self) -> Task:
        return Task(
            config=self.tasks_config["regulatory_safety_assessment"],
            markdown=False,
            
            
        )
    
    @task
    def scientific_literature_mechanism_analysis(self) -> Task:
        return Task(
            config=self.tasks_config["scientific_literature_mechanism_analysis"],
            markdown=False,
            
            
        )
    
    @task
    def research_quality_enhancement_verification(self) -> Task:
        return Task(
            config=self.tasks_config["research_quality_enhancement_verification"],
            markdown=False,
            
            
        )
    
    @task
    def comprehensive_drug_repurposing_report(self) -> Task:
        return Task(
            config=self.tasks_config["comprehensive_drug_repurposing_report"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the DrugRepurposingIntelligenceSystem crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )

    def _load_response_format(self, name):
        with open(os.path.join(self.base_directory, "config", f"{name}.json")) as f:
            json_schema = json.loads(f.read())

        return SchemaConverter.build(json_schema)
